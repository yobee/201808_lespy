# -*- coding: utf-8 -*-

print("Hello world!")

print(123)
